 // Function to generate a random fare between a specified range
    function generateRandomFare(min, max) {
        return (Math.random() * (max - min) + min).toFixed(2);
    }

    // Function to set a random fare in the fare input field
    function setRandomFare() {
        var minFare = 20.00; // Minimum fare value
        var maxFare = 100.00; // Maximum fare value
        var randomFare = generateRandomFare(minFare, maxFare);
        document.getElementById("fare").value = randomFare;
    }

    // Function to calculate discounted fare
    function calculateDiscountedFare() {
        var randomFare = parseFloat(document.getElementById("fare").value);
        var discount = 0.1; // 5% discount
        var discountedFare = (randomFare - (randomFare * discount)).toFixed(2);
        document.getElementById("fare").value = discountedFare;
        document.getElementById("discountedFare").innerHTML = "Discounted Fare: ₹" + discountedFare;
        document.getElementById("checkReferralCodeButton").style.display = "none";
    }

    // Call setRandomFare when the page loads to set a random fare
    window.onload = setRandomFare;
